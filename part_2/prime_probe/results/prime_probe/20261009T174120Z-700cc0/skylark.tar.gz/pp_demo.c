/* Guess one bit from the cache set read by a toy victim.
 * Defaults match Skylark (AMD EPYC 7532): 8 ways, 64-byte lines,
 * and 64 sets. Override WAYS, LINE_SIZE, or STRIDE for another geometry.
 * Build: gcc -O2 -Wall -Wextra -std=c11 pp_demo.c -o pp_demo
 * Run:   ./pp_demo 0   or   ./pp_demo 1
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <x86intrin.h>

#ifndef WAYS
#define WAYS 8
#endif
#ifndef LINE_SIZE
#define LINE_SIZE 64
#endif
#ifndef STRIDE
#define STRIDE 4096
#endif
#define TRIALS 5000

// Keep the volatile memory read between the TSC timestamps.
static uint64_t time_load(volatile uint8_t *address) {
    unsigned int cpu_id;
    _mm_lfence();
    uint64_t start = __rdtsc();
    _mm_lfence();
    (void)*address;
    _mm_lfence();
    uint64_t end = __rdtscp(&cpu_id);
    _mm_lfence();
    return end - start;
}

// Fill one set with attacker lines spaced by the set-index period.
static void prime(volatile uint8_t *base) {
    for (int i = 0; i < WAYS; ++i) {
        (void)base[i * STRIDE];
    }
}

// Sum the timed reads of those same attacker lines.
static uint64_t probe(volatile uint8_t *base) {
    uint64_t ticks = 0;
    for (int i = 0; i < WAYS; ++i) {
        ticks += time_load(base + i * STRIDE);
    }
    return ticks;
}

// The victim's separate lines compete for set A (bit 0) or set B (bit 1).
__attribute__((noinline))
static void victim(int secret, volatile uint8_t *base) {
    prime(base + secret * LINE_SIZE);
}

int main(int argc, char **argv) {
    if (argc > 2 || (argc == 2 && strcmp(argv[1], "0") != 0 &&
                                strcmp(argv[1], "1") != 0)) {
        fprintf(stderr, "Usage: %s [0|1]\n", argv[0]);
        return 2;
    }
    int secret = argc == 2 ? atoi(argv[1]) : 1;

    // The first half holds attacker lines; the second holds victim lines.
    const size_t bytes = 2 * (size_t)WAYS * STRIDE;
    uint8_t *memory = aligned_alloc(STRIDE, bytes);
    if (memory == NULL) {
        fprintf(stderr, "Memory allocation failed.\n");
        return 1;
    }
    memset(memory, 0, bytes); // Fault in the pages before any trial.
    volatile uint8_t *set_a = memory;
    volatile uint8_t *set_b = memory + LINE_SIZE;
    volatile uint8_t *victim_base = memory + WAYS * STRIDE;

    int correct = 0;
    uint64_t total_a = 0, total_b = 0;
    puts("trial,score_a_ticks,score_b_ticks,guess");

    for (int trial = 0; trial < TRIALS; ++trial) {
        // 1. Prime both attacker sets.
        prime(set_a);
        prime(set_b);

        // 2. Victim: touch one set based on the secret.
        victim(secret, victim_base);

        // 3. Probe both sets, alternating which one goes first.
        uint64_t time_a, time_b;
        if (trial % 2 == 0) {
            time_a = probe(set_a);
            time_b = probe(set_b);
        } else {
            time_b = probe(set_b);
            time_a = probe(set_a);
        }

        // 4. The slower set predicts the bit; compare with the known value.
        int guess = time_b > time_a ? 1 : 0; // Ties count as 0.
        if (guess == secret) {
            ++correct;
        }
        total_a += time_a;
        total_b += time_b;
        printf("%d,%" PRIu64 ",%" PRIu64 ",%d\n", trial, time_a, time_b, guess);
    }

    fprintf(stderr, "Expected bit: %d; correct guesses: %d/%d (%.1f%%)\n",
            secret, correct, TRIALS, 100.0 * correct / TRIALS);
    fprintf(stderr, "Mean set A: %.1f ticks; mean set B: %.1f ticks\n",
            (double)total_a / TRIALS, (double)total_b / TRIALS);
    free(memory);
    return 0;
}
